import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';

export interface AdoStoryWebhookStackProps extends cdk.StackProps {
  deployEnv: string;
  imageTag: string;
}

export class AdoStoryWebhookStack extends cdk.Stack {
  readonly functionUrl: lambda.FunctionUrl;

  constructor(scope: Construct, id: string, props: AdoStoryWebhookStackProps) {
    super(scope, id, props);

    const { deployEnv, imageTag } = props;

    // ── ECR ──────────────────────────────────────────────────────────────────
    const repository = new ecr.Repository(this, 'Repository', {
      repositoryName: 'ado-story-webhook',
      imageScanOnPush: true,
      imageTagMutability: ecr.TagMutability.IMMUTABLE,
      lifecycleRules: [
        { maxImageCount: 10, description: 'keep last 10 images' },
      ],
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // ── SQS ──────────────────────────────────────────────────────────────────
    const dlq = new sqs.Queue(this, 'Dlq', {
      queueName: `ado-story-events-dlq-${deployEnv}.fifo`,
      fifo: true,
      encryption: sqs.QueueEncryption.KMS_MANAGED,
      retentionPeriod: cdk.Duration.days(14),
    });

    const queue = new sqs.Queue(this, 'Queue', {
      queueName: `ado-story-events-${deployEnv}.fifo`,
      fifo: true,
      contentBasedDeduplication: false,
      encryption: sqs.QueueEncryption.KMS_MANAGED,
      visibilityTimeout: cdk.Duration.seconds(30),
      retentionPeriod: cdk.Duration.days(4),
      deadLetterQueue: { queue: dlq, maxReceiveCount: 3 },
    });

    // ── Secrets ───────────────────────────────────────────────────────────────
    const basicPasswordSecret = new secretsmanager.Secret(this, 'BasicPasswordSecret', {
      secretName: `ado-story-webhook/${deployEnv}/basic-password`,
      description: 'ADO webhook basic auth credentials',
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ username: 'ado' }),
        generateStringKey: 'password',
        excludePunctuation: true,
        passwordLength: 32,
      },
    });

    // ── Lambda execution role ─────────────────────────────────────────────────
    const logGroup = new logs.LogGroup(this, 'LogGroup', {
      logGroupName: `/aws/lambda/ado-story-webhook-${deployEnv}`,
      retention: logs.RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    const executionRole = new iam.Role(this, 'ExecutionRole', {
      roleName: `ado-story-webhook-${deployEnv}-role`,
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      inlinePolicies: {
        sqsSend: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              sid: 'SqsSend',
              actions: ['sqs:SendMessage', 'sqs:GetQueueAttributes'],
              resources: [queue.queueArn],
            }),
          ],
        }),
        logging: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              sid: 'Logging',
              actions: ['logs:CreateLogGroup', 'logs:CreateLogStream', 'logs:PutLogEvents'],
              resources: [logGroup.logGroupArn, `${logGroup.logGroupArn}:*`],
            }),
          ],
        }),
        secrets: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              sid: 'Secrets',
              actions: ['secretsmanager:GetSecretValue'],
              resources: [basicPasswordSecret.secretArn],
            }),
          ],
        }),
      },
    });

    // ── Lambda ────────────────────────────────────────────────────────────────
    const fn = new lambda.DockerImageFunction(this, 'Function', {
      functionName: `ado-story-webhook-${deployEnv}`,
      code: lambda.DockerImageCode.fromEcr(repository, { tagOrDigest: imageTag }),
      role: executionRole,
      memorySize: 512,
      timeout: cdk.Duration.seconds(15),
      logGroup,
      environment: {
        NODE_ENV: 'production',
        SQS_QUEUE_URL: queue.queueUrl,
        SQS_SCHEMA_VERSION: '1',
        WEBHOOK_AUTH_MODE: 'basic',
        ALLOWED_EVENT_TYPES: 'workitem.updated',
        ALLOWED_WORK_ITEM_TYPES: 'User Story',
        REQUIRE_STATE_CHANGE: 'true',
        LOG_LEVEL: 'info',
        SERVICE_NAME: 'ado-story-webhook',
        // Secrets resolved by CDK at deploy time — injected as plaintext Lambda env vars.
        // For higher compliance posture, switch to fetch-at-cold-start (see docs/security.md).
        WEBHOOK_BASIC_USER: basicPasswordSecret
          .secretValueFromJson('username')
          .unsafeUnwrap(),
        WEBHOOK_BASIC_PASSWORD: basicPasswordSecret
          .secretValueFromJson('password')
          .unsafeUnwrap(),
      },
    });

    // ── Function URL (public HTTPS entry point) ───────────────────────────────
    this.functionUrl = fn.addFunctionUrl({
      authType: lambda.FunctionUrlAuthType.NONE,
      cors: { allowedOrigins: [] },
    });

    // ── CloudWatch Alarms ─────────────────────────────────────────────────────
    new cloudwatch.Alarm(this, 'DlqDepthAlarm', {
      alarmName: `ado-story-webhook-${deployEnv}-dlq-depth`,
      alarmDescription: 'Messages landed in DLQ — investigate immediately',
      metric: dlq.metricApproximateNumberOfMessagesVisible({ period: cdk.Duration.minutes(1) }),
      threshold: 0,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
      evaluationPeriods: 1,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    });

    new cloudwatch.Alarm(this, 'LambdaErrorAlarm', {
      alarmName: `ado-story-webhook-${deployEnv}-errors`,
      alarmDescription: 'Lambda invocation errors exceeded threshold',
      metric: fn.metricErrors({ period: cdk.Duration.minutes(5) }),
      threshold: 5,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
      evaluationPeriods: 1,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    });

    // ── Outputs ───────────────────────────────────────────────────────────────
    new cdk.CfnOutput(this, 'WebhookUrl', {
      value: this.functionUrl.url,
      description: 'Lambda Function URL — configure this in the ADO Service Hook',
    });

    new cdk.CfnOutput(this, 'QueueUrl', {
      value: queue.queueUrl,
      description: 'SQS FIFO queue URL',
    });

    new cdk.CfnOutput(this, 'DlqUrl', {
      value: dlq.queueUrl,
      description: 'Dead letter queue URL',
    });

    new cdk.CfnOutput(this, 'EcrRepository', {
      value: repository.repositoryUri,
      description: 'ECR repository URI — push images here',
    });

    new cdk.CfnOutput(this, 'BasicPasswordSecretArn', {
      value: basicPasswordSecret.secretArn,
      description: 'Rotate this secret after first deploy, then redeploy',
    });
  }
}
