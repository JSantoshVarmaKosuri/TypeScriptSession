import { describe, it, expect, vi } from 'vitest';

const mockConfig = vi.hoisted(() => ({
  sqsQueueUrl: 'https://sqs.us-east-1.amazonaws.com/123456789/ado-story-events-dev.fifo',
  sqsQueueType: 'fifo' as 'fifo' | 'standard',
  sqsSchemaVersion: '1',
  sqsMessageGroupStrategy: 'per-work-item',
  awsRegion: 'us-east-1',
  authMode: 'basic' as 'basic' | 'header' | 'both' | 'none',
  basicUser: 'user',
  basicPassword: 'pass',
  secretHeaderName: 'x-ado-webhook-token',
  secretToken: '',
  allowedEventTypes: ['workitem.updated'],
  allowedWorkItemTypes: ['User Story'],
  requireStateChange: true,
  maxBodyBytes: 262144,
  nodeEnv: 'test',
  logLevel: 'info',
  serviceName: 'ado-story-webhook',
}));

vi.mock('../../src/config', () => ({ config: mockConfig }));

import { buildSqsInput } from '../../src/transform';
import type { ParsedPayload } from '../../src/payload';

const basePayload: ParsedPayload = {
  eventType: 'workitem.updated',
  eventId: 'evt-001',
  workItemId: 12345,
  rev: 7,
  status: 'Resolved',
  previousStatus: 'Active',
  workItemType: 'User Story',
  areaPath: 'MyProject\\Team A',
  project: 'MyProject',
  changedAt: '2024-06-25T10:00:00Z',
};

describe('buildSqsInput', () => {
  it('produces correct message body', () => {
    const input = buildSqsInput(basePayload);
    expect(JSON.parse(input.MessageBody!)).toEqual({ workItemId: 12345, status: 'Resolved' });
  });

  it('sets FIFO MessageGroupId and MessageDeduplicationId', () => {
    mockConfig.sqsQueueType = 'fifo';
    const input = buildSqsInput(basePayload);
    expect(input.MessageGroupId).toBe('12345');
    expect(input.MessageDeduplicationId).toBe('12345:7');
  });

  it('includes all message attributes', () => {
    const input = buildSqsInput(basePayload);
    const attrs = input.MessageAttributes!;
    expect(attrs.schemaVersion?.StringValue).toBe('1');
    expect(attrs.eventType?.StringValue).toBe('workitem.updated');
    expect(attrs.source?.StringValue).toBe('ado-story-webhook');
    expect(attrs.workItemType?.StringValue).toBe('User Story');
    expect(attrs.rev?.StringValue).toBe('7');
    expect(attrs.previousStatus?.StringValue).toBe('Active');
    expect(attrs.changedAt?.StringValue).toBe('2024-06-25T10:00:00Z');
    expect(attrs.project?.StringValue).toBe('MyProject');
  });

  it('falls back to hash of eventId when rev is undefined', () => {
    const p: ParsedPayload = { ...basePayload, rev: undefined };
    const input = buildSqsInput(p);
    expect(input.MessageDeduplicationId).toMatch(/^12345:[a-f0-9]+$/);
  });

  it('omits FIFO params for standard queue', () => {
    mockConfig.sqsQueueType = 'standard';
    const input = buildSqsInput(basePayload);
    expect(input.MessageGroupId).toBeUndefined();
    expect(input.MessageDeduplicationId).toBeUndefined();
    mockConfig.sqsQueueType = 'fifo';
  });

  it('omits optional attributes when not present', () => {
    const p: ParsedPayload = {
      eventType: 'workitem.updated',
      eventId: undefined,
      workItemId: 9999,
      rev: undefined,
      status: 'New',
      previousStatus: undefined,
      workItemType: undefined,
      areaPath: undefined,
      project: undefined,
      changedAt: undefined,
    };
    const input = buildSqsInput(p);
    const attrs = input.MessageAttributes!;
    expect(attrs.workItemType).toBeUndefined();
    expect(attrs.rev).toBeUndefined();
    expect(attrs.previousStatus).toBeUndefined();
    expect(attrs.changedAt).toBeUndefined();
    expect(attrs.project).toBeUndefined();
  });
});
