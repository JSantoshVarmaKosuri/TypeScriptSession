import { describe, it, expect, vi, beforeEach } from 'vitest';

beforeEach(() => {
  vi.resetModules();
});

async function loadConfig(env: Record<string, string | undefined>) {
  for (const [k, v] of Object.entries(env)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
  return import('../../src/config');
}

describe('config validation', () => {
  it('throws when SQS_QUEUE_URL is missing', async () => {
    await expect(
      loadConfig({ SQS_QUEUE_URL: undefined, NODE_ENV: 'development', WEBHOOK_AUTH_MODE: 'none' })
    ).rejects.toThrow('SQS_QUEUE_URL');
    vi.resetModules();
  });

  it('throws when authMode=none in production', async () => {
    await expect(
      loadConfig({
        SQS_QUEUE_URL: 'https://sqs.us-east-1.amazonaws.com/123/q.fifo',
        NODE_ENV: 'production',
        WEBHOOK_AUTH_MODE: 'none',
      })
    ).rejects.toThrow('none');
    vi.resetModules();
  });

  it('auto-detects fifo queue type from URL suffix', async () => {
    process.env.SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/123/q.fifo';
    process.env.NODE_ENV = 'development';
    process.env.WEBHOOK_AUTH_MODE = 'none';
    vi.resetModules();
    const { config } = await import('../../src/config');
    expect(config.sqsQueueType).toBe('fifo');
  });

  it('auto-detects standard queue type', async () => {
    process.env.SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/123/my-queue';
    process.env.NODE_ENV = 'development';
    process.env.WEBHOOK_AUTH_MODE = 'none';
    vi.resetModules();
    const { config } = await import('../../src/config');
    expect(config.sqsQueueType).toBe('standard');
  });

  it('parses allowedEventTypes as list', async () => {
    process.env.SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/123/q.fifo';
    process.env.NODE_ENV = 'development';
    process.env.WEBHOOK_AUTH_MODE = 'none';
    process.env.ALLOWED_EVENT_TYPES = 'workitem.updated,workitem.created';
    vi.resetModules();
    const { config } = await import('../../src/config');
    expect(config.allowedEventTypes).toEqual(['workitem.updated', 'workitem.created']);
    delete process.env.ALLOWED_EVENT_TYPES;
  });
});
