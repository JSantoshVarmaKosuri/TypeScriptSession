import { describe, it, expect, vi } from 'vitest';

const mockConfig = vi.hoisted(() => ({
  authMode: 'basic' as 'basic' | 'header' | 'both' | 'none',
  basicUser: 'ado',
  basicPassword: 'secret123',
  secretHeaderName: 'x-ado-webhook-token',
  secretToken: 'tok-abc',
  nodeEnv: 'development',
  sqsQueueUrl: 'http://localhost:4566/queue.fifo',
  sqsQueueType: 'fifo' as 'fifo' | 'standard',
  awsRegion: 'us-east-1',
  sqsSchemaVersion: '1',
  sqsMessageGroupStrategy: 'per-work-item',
  allowedEventTypes: ['workitem.updated'],
  allowedWorkItemTypes: ['User Story'],
  requireStateChange: true,
  maxBodyBytes: 262144,
  logLevel: 'info',
  serviceName: 'ado-story-webhook',
}));

vi.mock('../../src/config', () => ({ config: mockConfig }));

import { authenticate } from '../../src/auth';

function makeRequest(opts: { authorization?: string; token?: string } = {}): Request {
  const headers = new Headers();
  if (opts.authorization) headers.set('authorization', opts.authorization);
  if (opts.token) headers.set('x-ado-webhook-token', opts.token);
  return new Request('https://example.com/api/ado/webhook', { method: 'POST', headers });
}

function basicHeader(user: string, pass: string): string {
  return 'Basic ' + Buffer.from(`${user}:${pass}`).toString('base64');
}

describe('authenticate – basic mode', () => {
  it('passes with correct credentials', () => {
    mockConfig.authMode = 'basic';
    expect(authenticate(makeRequest({ authorization: basicHeader('ado', 'secret123') })).ok).toBe(true);
  });

  it('rejects wrong password', () => {
    mockConfig.authMode = 'basic';
    expect(authenticate(makeRequest({ authorization: basicHeader('ado', 'wrong') })).ok).toBe(false);
  });

  it('rejects wrong user', () => {
    mockConfig.authMode = 'basic';
    expect(authenticate(makeRequest({ authorization: basicHeader('wrong', 'secret123') })).ok).toBe(false);
  });

  it('rejects missing header', () => {
    mockConfig.authMode = 'basic';
    expect(authenticate(makeRequest()).ok).toBe(false);
  });

  it('rejects non-Basic scheme', () => {
    mockConfig.authMode = 'basic';
    expect(authenticate(makeRequest({ authorization: 'Bearer token' })).ok).toBe(false);
  });
});

describe('authenticate – header mode', () => {
  it('passes with correct token', () => {
    mockConfig.authMode = 'header';
    expect(authenticate(makeRequest({ token: 'tok-abc' })).ok).toBe(true);
  });

  it('rejects wrong token', () => {
    mockConfig.authMode = 'header';
    expect(authenticate(makeRequest({ token: 'wrong' })).ok).toBe(false);
  });

  it('rejects missing token', () => {
    mockConfig.authMode = 'header';
    expect(authenticate(makeRequest()).ok).toBe(false);
  });
});

describe('authenticate – both mode', () => {
  it('passes when both are correct', () => {
    mockConfig.authMode = 'both';
    expect(authenticate(makeRequest({ authorization: basicHeader('ado', 'secret123'), token: 'tok-abc' })).ok).toBe(true);
  });

  it('rejects when only basic correct', () => {
    mockConfig.authMode = 'both';
    expect(authenticate(makeRequest({ authorization: basicHeader('ado', 'secret123'), token: 'wrong' })).ok).toBe(false);
  });

  it('rejects when only header correct', () => {
    mockConfig.authMode = 'both';
    expect(authenticate(makeRequest({ authorization: basicHeader('ado', 'wrong'), token: 'tok-abc' })).ok).toBe(false);
  });
});

describe('authenticate – none mode', () => {
  it('always passes', () => {
    mockConfig.authMode = 'none';
    expect(authenticate(makeRequest()).ok).toBe(true);
  });
});
