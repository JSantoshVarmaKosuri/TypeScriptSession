import { describe, it, expect } from 'vitest';
import { parsePayload, isParseError } from '../../src/payload';

import stateChange from '../fixtures/workitem-updated-state-change.json';
import noStateChange from '../fixtures/workitem-updated-no-state-change.json';
import nonUserStory from '../fixtures/workitem-updated-non-user-story.json';
import fallback from '../fixtures/workitem-updated-fallback-extraction.json';
import malformed from '../fixtures/workitem-malformed.json';

describe('parsePayload', () => {
  it('parses normal state change', () => {
    const result = parsePayload(stateChange);
    expect(isParseError(result)).toBe(false);
    if (isParseError(result)) return;
    expect(result.workItemId).toBe(12345);
    expect(result.rev).toBe(7);
    expect(result.status).toBe('Resolved');
    expect(result.previousStatus).toBe('Active');
    expect(result.workItemType).toBe('User Story');
    expect(result.areaPath).toBe('MyProject\\Team A');
    expect(result.project).toBe('MyProject');
    expect(result.changedAt).toBe('2024-06-25T10:00:00Z');
  });

  it('parses no-state-change event', () => {
    const result = parsePayload(noStateChange);
    expect(isParseError(result)).toBe(false);
    if (isParseError(result)) return;
    expect(result.status).toBe('Active');
    expect(result.previousStatus).toBe('Active');
  });

  it('parses non-User Story work item', () => {
    const result = parsePayload(nonUserStory);
    expect(isParseError(result)).toBe(false);
    if (isParseError(result)) return;
    expect(result.workItemType).toBe('Bug');
  });

  it('falls back to revision.id and url for id/rev', () => {
    const result = parsePayload(fallback);
    expect(isParseError(result)).toBe(false);
    if (isParseError(result)) return;
    expect(result.workItemId).toBe(55555);
    expect(result.rev).toBe(2);
  });

  it('returns error for malformed payload (missing eventType)', () => {
    const result = parsePayload(malformed);
    expect(isParseError(result)).toBe(true);
  });

  it('returns error for non-object input', () => {
    expect(isParseError(parsePayload(null))).toBe(true);
    expect(isParseError(parsePayload('string'))).toBe(true);
    expect(isParseError(parsePayload(42))).toBe(true);
  });

  it('returns error when workItemId cannot be determined', () => {
    const payload = {
      eventType: 'workitem.updated',
      resource: { fields: {}, revision: { fields: {} }, url: 'https://example.com/no-id' },
    };
    const result = parsePayload(payload);
    expect(isParseError(result)).toBe(true);
  });
});
