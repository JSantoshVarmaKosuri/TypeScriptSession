import { SQSClient, SendMessageCommand, type SendMessageCommandInput } from '@aws-sdk/client-sqs';
import { config } from './config';

const client = new SQSClient({ region: config.awsRegion });

export class SqsError extends Error {
  constructor(
    message: string,
    public readonly cause?: unknown
  ) {
    super(message);
    this.name = 'SqsError';
  }
}

export async function enqueue(input: SendMessageCommandInput): Promise<void> {
  try {
    await client.send(new SendMessageCommand(input));
  } catch (err) {
    throw new SqsError('Failed to send message to SQS', err);
  }
}
