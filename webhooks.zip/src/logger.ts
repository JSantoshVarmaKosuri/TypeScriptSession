type Level = 'debug' | 'info' | 'warn' | 'error';

const LEVELS: Record<Level, number> = { debug: 0, info: 1, warn: 2, error: 3 };

const configuredLevel = (): Level => {
  const v = (process.env.LOG_LEVEL ?? 'info').toLowerCase();
  return (v in LEVELS ? v : 'info') as Level;
};

export type LogFields = {
  correlationId?: string;
  eventType?: string;
  workItemId?: number;
  rev?: number;
  workItemType?: string;
  outcome?: 'enqueued' | 'ignored' | 'unauthorized' | 'bad_request' | 'error';
  statusCode?: number;
  durationMs?: number;
  errorName?: string;
  message?: string;
};

function write(level: Level, msg: string, fields: LogFields = {}): void {
  if (LEVELS[level] < LEVELS[configuredLevel()]) return;
  const entry = {
    level,
    service: process.env.SERVICE_NAME ?? 'ado-story-webhook',
    timestamp: new Date().toISOString(),
    msg,
    ...fields,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

export const logger = {
  debug: (msg: string, fields?: LogFields) => write('debug', msg, fields),
  info: (msg: string, fields?: LogFields) => write('info', msg, fields),
  warn: (msg: string, fields?: LogFields) => write('warn', msg, fields),
  error: (msg: string, fields?: LogFields) => write('error', msg, fields),
};
