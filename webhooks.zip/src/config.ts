function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

function parseBoolean(name: string, fallback: boolean): boolean {
  const v = process.env[name];
  if (v === undefined) return fallback;
  return v.toLowerCase() !== 'false' && v !== '0';
}

function parseNumber(name: string, fallback: number): number {
  const v = process.env[name];
  if (!v) return fallback;
  const n = parseInt(v, 10);
  if (isNaN(n)) throw new Error(`Env var ${name} must be a number, got: ${v}`);
  return n;
}

function parseList(name: string, fallback: string): string[] {
  const v = process.env[name] ?? fallback;
  return v
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

const nodeEnv = optional('NODE_ENV', 'development');
const sqsQueueUrl = required('SQS_QUEUE_URL');
const sqsQueueType = sqsQueueUrl.endsWith('.fifo') ? 'fifo' : 'standard';

const authMode = optional('WEBHOOK_AUTH_MODE', 'basic') as
  | 'basic'
  | 'header'
  | 'both'
  | 'none';

if (nodeEnv === 'production' && authMode === 'none') {
  throw new Error('WEBHOOK_AUTH_MODE=none is not allowed in production');
}

if ((authMode === 'basic' || authMode === 'both') && nodeEnv === 'production') {
  if (!process.env.WEBHOOK_BASIC_USER || !process.env.WEBHOOK_BASIC_PASSWORD) {
    throw new Error(
      'WEBHOOK_BASIC_USER and WEBHOOK_BASIC_PASSWORD required when authMode includes basic'
    );
  }
}

if ((authMode === 'header' || authMode === 'both') && nodeEnv === 'production') {
  if (!process.env.WEBHOOK_SECRET_TOKEN) {
    throw new Error('WEBHOOK_SECRET_TOKEN required when authMode includes header');
  }
}

export const config = {
  nodeEnv,
  logLevel: optional('LOG_LEVEL', 'info'),
  serviceName: optional('SERVICE_NAME', 'ado-story-webhook'),

  sqsQueueUrl,
  sqsQueueType: sqsQueueType as 'fifo' | 'standard',
  awsRegion: optional('AWS_REGION', 'us-east-1'),
  sqsSchemaVersion: optional('SQS_SCHEMA_VERSION', '1'),
  sqsMessageGroupStrategy: optional('SQS_MESSAGE_GROUP_STRATEGY', 'per-work-item'),

  authMode,
  basicUser: process.env.WEBHOOK_BASIC_USER ?? '',
  basicPassword: process.env.WEBHOOK_BASIC_PASSWORD ?? '',
  secretHeaderName: optional('WEBHOOK_SECRET_HEADER_NAME', 'x-ado-webhook-token'),
  secretToken: process.env.WEBHOOK_SECRET_TOKEN ?? '',

  allowedEventTypes: parseList('ALLOWED_EVENT_TYPES', 'workitem.updated'),
  allowedWorkItemTypes: parseList('ALLOWED_WORK_ITEM_TYPES', 'User Story'),
  allowedAreaPathPrefix: process.env.ALLOWED_AREA_PATH_PREFIX,
  requireStateChange: parseBoolean('REQUIRE_STATE_CHANGE', true),

  maxBodyBytes: parseNumber('MAX_BODY_BYTES', 262144),
} as const;
