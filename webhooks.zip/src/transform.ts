import { createHash } from 'crypto';
import type { SendMessageCommandInput } from '@aws-sdk/client-sqs';
import { config } from './config';
import type { ParsedPayload } from './payload';

type SqsAttr = {
  DataType: 'String' | 'Number';
  StringValue?: string;
};

function strAttr(value: string): SqsAttr {
  return { DataType: 'String', StringValue: value };
}

function numAttr(value: number): SqsAttr {
  return { DataType: 'Number', StringValue: String(value) };
}

function deduplicationId(payload: ParsedPayload): string {
  if (payload.rev !== undefined) {
    return `${payload.workItemId}:${payload.rev}`;
  }
  const fallback = payload.eventId
    ? createHash('sha256').update(payload.eventId).digest('hex').slice(0, 16)
    : String(Date.now());
  return `${payload.workItemId}:${fallback}`;
}

export function buildSqsInput(payload: ParsedPayload): SendMessageCommandInput {
  const body = JSON.stringify({
    workItemId: payload.workItemId,
    status: payload.status ?? '',
  });

  const attrs: Record<string, SqsAttr> = {
    schemaVersion: strAttr(config.sqsSchemaVersion),
    eventType: strAttr(payload.eventType),
    source: strAttr('ado-story-webhook'),
  };

  if (payload.workItemType) attrs.workItemType = strAttr(payload.workItemType);
  if (payload.rev !== undefined) attrs.rev = numAttr(payload.rev);
  if (payload.previousStatus) attrs.previousStatus = strAttr(payload.previousStatus);
  if (payload.changedAt) attrs.changedAt = strAttr(payload.changedAt);
  if (payload.project) attrs.project = strAttr(payload.project);

  const input: SendMessageCommandInput = {
    QueueUrl: config.sqsQueueUrl,
    MessageBody: body,
    MessageAttributes: attrs,
  };

  if (config.sqsQueueType === 'fifo') {
    input.MessageGroupId = String(payload.workItemId);
    input.MessageDeduplicationId = deduplicationId(payload);
  }

  return input;
}
