import { z } from 'zod';

const StateFieldSchema = z
  .object({
    oldValue: z.string().optional(),
    newValue: z.string().optional(),
  })
  .passthrough()
  .optional();

const FieldsSchema = z
  .object({
    'System.State': StateFieldSchema,
    'System.ChangedDate': StateFieldSchema,
  })
  .passthrough()
  .optional();

const RevisionFieldsSchema = z
  .object({
    'System.State': z.string().optional(),
    'System.WorkItemType': z.string().optional(),
    'System.AreaPath': z.string().optional(),
  })
  .passthrough()
  .optional();

const RevisionSchema = z
  .object({
    id: z.number().optional(),
    fields: RevisionFieldsSchema,
  })
  .passthrough()
  .optional();

const ResourceSchema = z
  .object({
    workItemId: z.number().optional(),
    rev: z.number().optional(),
    url: z.string().optional(),
    fields: FieldsSchema,
    revision: RevisionSchema,
  })
  .passthrough();

const ResourceContainersSchema = z
  .object({
    project: z
      .object({ name: z.string().optional() })
      .passthrough()
      .optional(),
  })
  .passthrough()
  .optional();

const AdoPayloadSchema = z
  .object({
    eventType: z.string(),
    id: z.string().optional(),
    resource: ResourceSchema,
    resourceContainers: ResourceContainersSchema,
  })
  .passthrough();

export type ParsedPayload = {
  eventType: string;
  eventId: string | undefined;
  workItemId: number;
  rev: number | undefined;
  status: string | undefined;
  previousStatus: string | undefined;
  workItemType: string | undefined;
  areaPath: string | undefined;
  project: string | undefined;
  changedAt: string | undefined;
};

export type ParseError = { error: string };

function parseIdFromUrl(url: string | undefined): number | undefined {
  if (!url) return undefined;
  const match = url.match(/workItems\/(\d+)/i);
  return match ? parseInt(match[1], 10) : undefined;
}

function parseRevFromUrl(url: string | undefined): number | undefined {
  if (!url) return undefined;
  const match = url.match(/updates\/(\d+)/i);
  return match ? parseInt(match[1], 10) : undefined;
}

export function parsePayload(raw: unknown): ParsedPayload | ParseError {
  const result = AdoPayloadSchema.safeParse(raw);
  if (!result.success) {
    return { error: result.error.message };
  }

  const d = result.data;
  const r = d.resource;

  const workItemId =
    r.workItemId ??
    r.revision?.id ??
    parseIdFromUrl(r.url);

  if (workItemId === undefined || isNaN(workItemId)) {
    return { error: 'Could not determine workItemId from payload' };
  }

  const stateField = r.fields?.['System.State'];
  const status = stateField?.newValue ?? r.revision?.fields?.['System.State'];
  const previousStatus = stateField?.oldValue;

  const rev = r.rev ?? parseRevFromUrl(r.url);

  return {
    eventType: d.eventType,
    eventId: d.id,
    workItemId,
    rev,
    status,
    previousStatus,
    workItemType: r.revision?.fields?.['System.WorkItemType'],
    areaPath: r.revision?.fields?.['System.AreaPath'],
    project: d.resourceContainers?.project?.name,
    changedAt: r.fields?.['System.ChangedDate']?.newValue,
  };
}

export function isParseError(v: ParsedPayload | ParseError): v is ParseError {
  return 'error' in v;
}
