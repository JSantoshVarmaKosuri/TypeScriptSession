import { createHash, timingSafeEqual } from 'crypto';
import { config } from './config';

export type AuthResult = { ok: true } | { ok: false };

function sha256(value: string): Buffer {
  return createHash('sha256').update(value).digest();
}

function constantTimeEqual(a: string, b: string): boolean {
  return timingSafeEqual(sha256(a), sha256(b));
}

function checkBasic(request: Request): boolean {
  const header = request.headers.get('authorization') ?? '';
  if (!header.toLowerCase().startsWith('basic ')) return false;
  const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
  const colon = decoded.indexOf(':');
  if (colon === -1) return false;
  const user = decoded.slice(0, colon);
  const pass = decoded.slice(colon + 1);
  return (
    constantTimeEqual(user, config.basicUser) &&
    constantTimeEqual(pass, config.basicPassword)
  );
}

function checkHeader(request: Request): boolean {
  const token = request.headers.get(config.secretHeaderName) ?? '';
  return constantTimeEqual(token, config.secretToken);
}

export function authenticate(request: Request): AuthResult {
  if (config.authMode === 'none') return { ok: true };
  if (config.authMode === 'basic') return { ok: checkBasic(request) };
  if (config.authMode === 'header') return { ok: checkHeader(request) };
  // both
  return { ok: checkBasic(request) && checkHeader(request) };
}
