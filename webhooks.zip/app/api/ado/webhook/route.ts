import { randomUUID } from 'crypto';
import { config } from '@/src/config';
import { authenticate } from '@/src/auth';
import { parsePayload, isParseError } from '@/src/payload';
import { buildSqsInput } from '@/src/transform';
import { enqueue, SqsError } from '@/src/sqs';
import { logger } from '@/src/logger';

export async function POST(request: Request): Promise<Response> {
  const correlationId = randomUUID();
  const start = performance.now();

  const auth = authenticate(request);
  if (!auth.ok) {
    logger.warn('Webhook auth failed', { correlationId, outcome: 'unauthorized', statusCode: 401 });
    return new Response(null, { status: 401 });
  }

  const contentLength = Number(request.headers.get('content-length') ?? 0);
  if (contentLength > config.maxBodyBytes) {
    logger.warn('Request body too large', { correlationId, outcome: 'bad_request', statusCode: 413 });
    return new Response(null, { status: 413 });
  }

  let raw: unknown;
  try {
    const text = await request.text();
    if (Buffer.byteLength(text, 'utf8') > config.maxBodyBytes) {
      logger.warn('Request body too large', { correlationId, outcome: 'bad_request', statusCode: 413 });
      return new Response(null, { status: 413 });
    }
    raw = JSON.parse(text);
  } catch {
    logger.warn('JSON parse failed', { correlationId, outcome: 'bad_request', statusCode: 400 });
    return new Response(null, { status: 400 });
  }

  const parsed = parsePayload(raw);
  if (isParseError(parsed)) {
    logger.warn('Payload validation failed', { correlationId, outcome: 'bad_request', statusCode: 400 });
    return new Response(null, { status: 400 });
  }

  const { eventType, workItemId, rev, workItemType, areaPath, status, previousStatus } = parsed;

  if (!config.allowedEventTypes.includes(eventType)) {
    logger.info('Event type filtered', { correlationId, eventType, workItemId, rev, workItemType, outcome: 'ignored', statusCode: 200 });
    return new Response(null, { status: 200 });
  }

  if (
    config.allowedWorkItemTypes.length > 0 &&
    workItemType &&
    !config.allowedWorkItemTypes.includes(workItemType)
  ) {
    logger.info('Work item type filtered', { correlationId, eventType, workItemId, rev, workItemType, outcome: 'ignored', statusCode: 200 });
    return new Response(null, { status: 200 });
  }

  if (config.allowedAreaPathPrefix && areaPath && !areaPath.startsWith(config.allowedAreaPathPrefix)) {
    logger.info('Area path filtered', { correlationId, eventType, workItemId, rev, workItemType, outcome: 'ignored', statusCode: 200 });
    return new Response(null, { status: 200 });
  }

  if (config.requireStateChange && status !== undefined && status === previousStatus) {
    logger.info('No state change, filtered', { correlationId, eventType, workItemId, rev, workItemType, outcome: 'ignored', statusCode: 200 });
    return new Response(null, { status: 200 });
  }

  try {
    const sqsInput = buildSqsInput(parsed);
    await enqueue(sqsInput);
  } catch (err) {
    const isTransient = err instanceof SqsError;
    const statusCode = isTransient ? 503 : 500;
    logger.error('SQS enqueue failed', {
      correlationId,
      eventType,
      workItemId,
      rev,
      workItemType,
      outcome: 'error',
      statusCode,
      errorName: err instanceof Error ? err.name : 'UnknownError',
      durationMs: Math.round(performance.now() - start),
    });
    return new Response(null, { status: statusCode });
  }

  const durationMs = Math.round(performance.now() - start);
  logger.info('Enqueued', { correlationId, eventType, workItemId, rev, workItemType, outcome: 'enqueued', statusCode: 202, durationMs });
  return new Response(null, { status: 202 });
}
